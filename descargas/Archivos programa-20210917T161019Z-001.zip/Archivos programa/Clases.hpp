#pragma once
#include <string>
#include <iostream>
#include <vector>

using namespace std;
//Est� funci�n se ha creado para evitr constantemente hacer validaciones de numeros enteros en un rango, recibe el n inferior y superior, solo acepta numeros en este rango 
int validar(int n1, int n2, string cadena, string opciones)
{
	int n;
	do {
		cout << "\nIngrese " << cadena << " " << opciones << endl;
		cin >> n;
		if (n<n1 || n>n2)
			cout << "\nUsted presiono un numero mal, recuerde que las opciones son: " << opciones << endl;
	} while (n<n1 || n>n2);
	return n;
}
//estructura que tiene algunos de los datos de un alumno en la credencial
struct credencial
{
	string nombre = "";
	string id = "";
	string campus = "";
	string carrera = "";
	int edad = 0;
};
//declaracion de la clase estudianta
class estudiante
{
private:
	//declaraci�n de los atributos del estudiante
	credencial registr;//algunos de los datos que portan los alumnos en su credencial de la UP
	int covid = 0;//1 si el alumno tiene covid 0 en caso contrario
	int sem = 0;//semestre
	int materias = 0;//cuantas materias tiene
	int password = 0;//contrase�a del alumno
	int diaA = 0;//dia que asiste a la escuela el alumno (1 o 2), 0 no ha registrado que d�a va a ir a clases
public:
	//declaraci�n de funciones del alumno
	estudiante();//constructor
	~estudiante();//desctructor
	int getCovid();//devuelve si el alumno est� enfermo o no
	int avisar_covid();//cambia el estatus del sal�n de acuerdo a lo que reporte el alumno
	void llenar_datos();//pide los datos del alumno
	void set_everything(credencial, int, int, int, int, int);//Necesario para recibir datos del csv.
	void imp_datos();//imprime los datos del alumno
	string get_things();
	int permiso(string, int);//permite verificar si la persona que esta accediendo es quien dice ser
	void setDiaA(int);//asigna el valor del dia que esocgio el alumno
	int getDiaA();//regresa el valor del dia que escogio el alumno
	string getIDA();//Regresa el ID del alumno
};
//Metodo que regresa el ID del estudiante
string estudiante::getIDA() {
	return registr.id;
}
//Metodo que asigna el d�a que asistira a clases el estudiante
void estudiante::setDiaA(int n) {
	diaA = n;
}
//Metodo que regresa el d�a que ha reservado el estudiante
int estudiante::getDiaA() {
	return diaA;
}
//Metodo que regresa si el alumno est� enfermo(1) o no(0) o si asistio a clases enfermo(2)
int estudiante::getCovid() {
	return covid;
}
//Metodo que regresa el valor de 0 a 2 para cambiar la disponibilidad del sal�n en caso de ser 2, aqu� abajo solo se pregunta el estado del alumno en ralci�n a esta enfermedad y se le asigna el valor
int estudiante::avisar_covid() {
	covid = validar(0, 2, "si usted esta enfermo de COVID", "0 - no, 1 - si, 2 - Asisti a clases enfermo");
	return covid;
}
//Metodo que recibe un ID y una contrase�a para comprobar si concuerda con alguno de los alumnos previamente registrado, regresa 1 si se encontr� alguna coincidencia, 0 en caso contrario
int estudiante::permiso(string iden, int con) {
	int n;
	if (iden == registr.id && con == password) {
		n = 1;
	}
	else
		n = 0;
	return n;
}
string estudiante::get_things()//Manda los datos del estudiante respectivo al csv en el formato separado por comas.
{
	string mandar;
	mandar = registr.campus + "," + registr.carrera + "," + registr.id + "," + registr.nombre + "," + to_string(registr.edad) + "," + to_string(covid) + "," + to_string(sem) + "," + to_string(materias) + "," + to_string(password) + "," + to_string(diaA) + "\n";
	return mandar;
}
//constructor de la clase
estudiante::estudiante()
{
}
//destructor de la clase
estudiante::~estudiante()
{
}
//Este metodo se utiliza cuando se recuperan datos del csv y sirve para asignar los valores a los objetos de alumnos que se tenian previamente registrados
void estudiante::set_everything(credencial vregistr, int vcovid, int vsem, int vmaterias, int vpassword, int vdiaA)//Necesario para recibir datos del csv.
{
	registr = vregistr;
	covid = vcovid;
	sem = vsem;
	materias = vmaterias;
	password = vpassword;
	diaA = vdiaA;
}
//Este metodo se utiliza cuando se registra el alumno para hacer la instancia de un nuevo objeto estudiante
void estudiante::llenar_datos() {
	int s;
	cout << "Ingrese el nombre del alumno: ";
	cin >> registr.nombre;
	cout << "Ingrese el ID de " << registr.nombre << ": ";
	cin >> registr.id;
	registr.edad = validar(16, 90, "la edad del alumno", "(16-90 anios)");
	covid = validar(0, 1, "si esta enfermo de covid", "1 - si,0 - no");
	sem = validar(1, 10, " su semestre", "(1 - 10)");
	cout << "Ingrese a cual campus pertenece: ";
	cin >> registr.campus;
	cout << "Ingrese el nombre de su carrera: ";
	cin >> registr.carrera;
	cout << "Ingrese su contrasenia (solo numeros, no iniciar con cero)" << endl;
	cin >> password;
}
//imprime los datos del alumno
void estudiante::imp_datos() {
	cout << "\nNombre del alumno: " << registr.nombre << endl;
	cout << "ID del alumno: " << registr.id << endl;
	cout << "Edad del alumno: " << registr.edad << endl;
	cout << "COVID (1 o 2 - si, 0 - no): " << covid << endl;
	cout << "Pertenece a la sede: " << registr.campus << endl;
	cout << "Pertenece a la carrera de: " << registr.carrera << endl;
	cout << "Actualmente cursando el semestre: " << sem << endl;
	cout << "Reservo el dia " << diaA << endl;
}
//Declraci�n de la clase sal�n
class salon
{
private:
	//Declaraci�n de atributos
	string materia_name = "";//nombre de la materia que se imparte en tal sal�n
	int capacidad = 0;//Capacidad del sal�n
	int lugaresdis = 0;//me dice la cantidad de alumnos que se aceptan en un sal�n(la mitad de su capacida m�xima)y va disminuyendo conforme m�s alumnos reservan en el dia 1
	string ubicacion = "";//lugar fisico del sal�n en el campus
	int presencial = 0;//si la clase se da online o presencial
	int disponibilidad = 0;//si esta abierto o cerrado(se puede cerrar si hay caso de covid9) con 0 es cerrado
	int nclase = 0;//numero de identificaci�n de la clase
	vector<estudiante>info;//vector que almacena objetos de la clase estudiante
	int ingresos = 0;//lleva cuantos alumnos se han registrado
	int lugaresdis2 = 0;//me dice la cantidad de alumnos que se aceptan en un sal�n(la mitad de su capacida m�xima)y va disminuyendo conforme m�s alumnos reservan en el dia 2
public:
	salon();//Constructor de la clase
	~salon();//Destructor de la clase
	int llenar_datos();//LLena los datos cuando se crea un nuevo sal�n
	int modificar_lugares_disponibles(int);//Modifica los lugares disponibles en el d�a 1 y 2
	void imprimir();//Imrpime los adtos del sal�n
	int getDispo();//Obtiene la disponibilidad del sal�n 1 abierto , 0 cerrado
	int getnclase();//Obtiene el numero de la clase
	void nuevoEst();//Permite crear nuevos estudiantes y almacenarlos en el vetor de estudiantes (osea el de info)
	string send_data();//no s�
	void set_all(string, int, int, string, int, int, int, int);//Necesario para recibir datos del csv.
	void newEstudiantes(int i, credencial vregistr, int vcovid, int vsem, int vmaterias, int vpassword, int vdiaA);//crea un nuevo lugar en el vector
	vector<estudiante> getEstudiantes();//regresa todos los estudiantes en un vector
	estudiante getEstudiante(int);//regresa solo un estudiante
	int getCapacidad();//devuelve la capacidad del salon
	int getIn();//regresa cuantos alumnos se han registrado cada vez que se ha iniciado el programa
	int getSi();//regresa la cantidad de alumnos que tiene registrados el salon
	void setDIAA(int, int);
	void setCoSal(int);//llama a la funcion avisar covid de alumno y puede que cierre el salon;
	int getID();//Regresa ID del sal�n
};
//Metodo que regresa el numero de identificacion del salon
int salon::getID() {
	return nclase;
}
//Metodo que regresa el tama�o del vector que contiene a los alumnos
int salon::getSi() {
	return info.size();
}
//Metodo que regresa un objeto de la clase estudiante, regresa un en especifico, el indicado por la variable "i"
estudiante salon::getEstudiante(int i) {
	return info[i];
}
//Metodo que regresa el vactor completo de estudiantes, osea regresa a todos los estudiantes
vector<estudiante> salon::getEstudiantes() {
	return info;
}
//Metodo que regresa la capacidad del sal�n
int salon::getCapacidad() {
	return capacidad;
}
//Metodo que regresa cuanto ingresos se han hecho en el sal�n
int salon::getIn() {
	return ingresos;
}
//Metodo que sirve como puente para fijat que dia el estudiante ha decidido asistir a clases por eso se invoca a una funcion de estudisntes la de setDiaA que le da un valor a la variable dia de la clase estudiante y los hace especificamente al estudiante se�alado con la variable"i"
void salon::setDIAA(int i, int vdiaA) {
	info[i].setDiaA(vdiaA);
}
//Metodo que sirve para preguntar el estado del estudiante invocando a la funcion avisar_covid perteneciente a la clase estudiante que regresa un valor de acuerdo a estado que haya reportado el alumno en relaci�n a este enfermedad
//si regresa 2 el sal�n se cierra por ello la disponibilidad pasa a ser 0
void salon::setCoSal(int i) {
	int z = 0;
	z = info[i].avisar_covid();
	if (z == 2) {
		disponibilidad = 0;
	}
}
//incrementa el espacio del vector, y devuelve ese espacio listo para llenar datos, esta funci�n se utiliza cuando se recuperan los datos y le da valores a los objetos con datos ya guarddos en el csv
//llamando a la un metodo perteneciente a estudiantes el i indica posici�n del alumno en el vector, lo dem�s son atributos
void salon::newEstudiantes(int i, credencial vregistr, int vcovid, int vsem, int vmaterias, int vpassword, int vdiaA) {
	info.push_back(estudiante());
	info[i].set_everything(vregistr, vcovid, vsem, vmaterias, vpassword, vdiaA);
}
//Regresa el numero de clase del salon(alerta se repite)
int salon::getnclase() {
	return nclase;
}
//Metodo que devuelve a disponibilidad del sal�n
int salon::getDispo() {
	return disponibilidad;
}
//Metodo que aparece cuando el administrador desea conocer los datos del sal�n y este los imprime
void salon::imprimir() {
	int co = 0;
	cout << "Materia: " << materia_name << endl;
	cout << "Ubicacion: " << ubicacion << endl;
	cout << "Espacios del salon disponibles en el dia 1: " << lugaresdis << endl;
	cout << "Espacios del salon disponibles en el dia 2: " << lugaresdis2 << endl;
	cout << "Capacidad original del salon " << capacidad << endl;
	cout << "Numero de identificacion de la clase: " << nclase << endl;
	//En este caso el sal�n est� cerrado, puede ser por causas de que un alumno haya asistido a clases con covid(puede que el alumno luego se reporte curado y no imprima alumnos para ello hay otro if), en tal caso se imprimira la cantidad de alumnos que asistieron a la clase enfermos y se le dara la opci�n 
	//al administrador de abrir el sal�n
	if (disponibilidad == 0) {
		cout << "Lista de alumnos con COVID que asistieron a clase: " << endl;
		//los salones solo se cierran si un alumno fue a clase con covid
		for (int i = 0; i < info.size(); i++) {
			if (info[i].getCovid() == 2) {
				cout << "Alumno " << i + 1 << " asisitio a una clase con COVID" << endl;
				co = co + 1;
			}
		}
		//Si ya no hay alumnos enfermos pero el sal�n se hab�a cerrado por esta causa
		if (co == 0) {
			cout << "Actualmente ya no hay alumnos que reporten estar enfermos y que hayan asistido a esta clase" << endl;
			cout << "Abrir salon?" << endl;
			disponibilidad = validar(0, 1, "si desea abrir el salon", "0 - no, 1 - si");
		}
		//Recientemente un alumno asisitio a la clase enfermo y por ello se cerro el sal�n
		else {
			cout << "Si se imprimio un alumno no se recomienda abrir el salon" << endl;
			cout << "Se tiene registro de un alumno que asistio a clase con COVID, esta seguro de abrir el salon?" << endl;
			disponibilidad = validar(0, 1, "si quiere abrir el salon", "1 - si, 0 - no");
		}
	}
	else {
		cout << "Actualmente no se han presentado casos de COVID en este salon, desea cerrarlo?" << endl;
		disponibilidad = validar(0, 1, "si desea cerrar el salon", "0 - si, 1 - cancelar");
	}
}
//Constructor de la clase
salon::salon() {
}
//Destructor de la clase
salon::~salon() {
}
//Metodo que incremente o disminuye el n�mero de lugares disponibles del sal�n en el d�a 1 y 2
int salon::modificar_lugares_disponibles(int m) {//la m me dice si quiere agregar el primer o segundo dia si en m llega menos 1 o menos 2 es que quieres cancelar lugar
	int k = 0;
	cout << "Lugares disponibles el el dia 1: " << lugaresdis << endl << "Lugares disponibles en el dia 2: " << lugaresdis2 << endl;
	if (lugaresdis == 0 && m > 0) {
		cout << "\nLo sentimos ya no quedan m�s lugares en este salon" << endl;
		k = 0;
	}
	else if (lugaresdis >= 1 && m > 0) {
		if (m == 1) {
			lugaresdis = lugaresdis - 1;
			k = 1;
			cout << "Ahora quedan " << lugaresdis << " disponibles en el dia 1" << endl;
		}
		else {
			lugaresdis2 = lugaresdis2 - 1,
				k = 2;
			cout << "Ahora quedan " << lugaresdis2 << " disponibles en el dia 2" << endl;
		}
	}
	else if (m < 0) {
		if (m == -1) {
			lugaresdis = lugaresdis + 1;
			k = 0;
			cout << "Ahora quedan " << lugaresdis << " disponibles en el dia 1" << endl;
		}
		else if (m == -2) {
			lugaresdis2 = lugaresdis2 + 1;
			k = 0;
			cout << "Ahora quedan " << lugaresdis2 << " disponibles en el dia 2" << endl;
		}
	}
	return k;//este sera el valor que guardara el estudiante parta saber que dia registro o si no va a asistir
}
//Este metodo se utiliza cuando re va a registrar un sal�n (no para cuando se recuperan del csv), pide los datos del sal�n
int salon::llenar_datos() {
	cout << "Ingrese el nombre de la materia: ";
	cin >> materia_name;
	capacidad = validar(1, 50, " la capacidad de alumnos", "(1-50)");
	cout << "Ingrese la ubicacion del salon: ";
	cin >> ubicacion;
	presencial = validar(0, 1, " si esta clase esta disponible presencial", "1 - si, 0 - no");
	disponibilidad = 1;
	lugaresdis = int(capacidad / 2);
	lugaresdis2 = int(capacidad / 2);
	cout << "Ingrese el numero de la clase: ";
	cin >> nclase;
	return nclase;
}
//Este metodo se utiliza para crear a un nuevo objeto de la clase estudiante, con ingresos se obtieve la cantidad de alumnos ya registrados, se utiiza para checar que al momento de llenar los datos no se repita ning�n ID
void salon::nuevoEst()
{
	int ban = 0;
	ingresos = info.size();
	estudiante ingreso;//instancia de un nuevo objeto al cual se le llenaran datos con el metodo de abajo pertenenciente a estudiante
	ingreso.llenar_datos();
	//for que checa que no se repite ning�n ID
	for (int i = 0; i < info.size(); i++) {
		if (info[i].getIDA() == ingreso.getIDA())
			ban = 1;
	}
	if (ban == 1)
		cout << "\nEste ID ya ha sido registrado previamente " << endl;
	//Si no se repite ning�n ID se registra al nuevo estudiante en otro caso no lo hace
	else {
		info.push_back(ingreso);
		cout << "\n\tRegistro exitoso" << endl;
	}
}

string salon::send_data()//Manda la informaci�n del salon al csv en su formato separado por comas.
{
	string hello;
	hello = materia_name + "," + to_string(capacidad) + "," + to_string(lugaresdis) + "," + ubicacion + "," + to_string(presencial) + "," + to_string(disponibilidad) + ","
		+ to_string(nclase) + "," + to_string(lugaresdis2) + "\n";
	return hello;
}
// este metodo se utiliza cuando se recupera informaci�n del csv para asignarle valor a los salones registrados previamente
void salon::set_all(string vname, int vcapacidad, int vlugaresdis, string vubicacion, int vpresencial, int vdisponibilidad, int vnclase, int vdis2)//Necesario para recibir datos del csv.
{
	materia_name = vname;
	capacidad = vcapacidad;
	lugaresdis = vlugaresdis;
	ubicacion = vubicacion;
	presencial = vpresencial;
	disponibilidad = vdisponibilidad;
	nclase = vnclase;
	lugaresdis2 = vdis2;
}