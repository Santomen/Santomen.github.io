#pragma once
#include "clases.hpp"
#include <iostream>
#include <string>
#include <vector>
#include <array>
#include <fstream>
#include <sstream>
#include <ios>
using namespace std;
int validar(int, int, string, string);
void comprobar(salon&, int);
void send_stud(vector<estudiante>);
void send_room(salon);
int receive_room(salon&);

void comprobar(salon& sal, int capacity)//Recibe los datos de los alumnos del csv.
{//capacity conator de la capacidad del salon
	string registro;
	array<int, 10>comas = { 0 };// arreglo que guarda posiciÃ³n de las comas.
	int j = 1, contador = 0;
	credencial datos;
	int disease, semester, clases, pass, day;//Variables donde se guarda info del csv.
	ifstream myfile("Trial.csv");//Archivo que contiene a los alumnos.

	if (myfile.is_open())
	{
		cout << "\nEl archivo se esta abriendo" << endl;
		while ((getline(myfile, registro)))
		{
			if (contador == 0)//Utilizado para no guardar el encabezado del archivo csv.
			{
				contador = +1;
				continue;
			}
			int j = 1;
			for (int i = 0; i < registro.size(); i++)//For que utiliza las comas para ubicar cuando empieza y termina una variable.
			{
				if (registro.substr(i, 1) == ",")
				{
					comas[j] = i;
					j += 1;
				}
			}
			datos.campus = registro.substr(comas[0], comas[1] - comas[0]);//Guardado de los valores del csv a variables del programaen base a la posiciÃ³n de comas.
			datos.carrera = registro.substr(comas[1] + 1, comas[2] - comas[1] - 1);
			datos.id = registro.substr(comas[2] + 1, comas[3] - comas[2] - 1);
			datos.nombre = registro.substr(comas[3] + 1, comas[4] - comas[3] - 1);
			datos.edad = stoi(registro.substr(comas[4] + 1, comas[5] - comas[4] - 1));
			disease = stoi(registro.substr(comas[5] + 1, comas[6] - comas[5] - 1));
			semester = stoi(registro.substr(comas[6] + 1, comas[7] - comas[6] - 1));
			clases = stoi(registro.substr(comas[7] + 1, comas[8] - comas[7] - 1));
			pass = stoi(registro.substr(comas[8] + 1, comas[9] - comas[8] - 1));
			day = stoi(registro.substr(comas[9] + 1, registro.size() - comas[9] - 1));
			sal.newEstudiantes(contador - 1, datos, disease, semester, clases, pass, day);//Se asignan los valores de las variables al objeto estudiante.
			contador += 1;
			if (contador > capacity) //En caso de que se exceda la capacidad del salÃ³n ya no se guardarÃ¡n los alumnos registrados en el csv.
			{
				cout << "\nSalon lleno, datos de otros alumnos en el documento no incluidos";
				break;
			}
			cout << "alumno reuperado..." << endl;
		}
		myfile.close();
	}
	else
		cout << "\nError, ubicacion del archivo no encontrada...";
}

void send_stud(vector<estudiante>personas)//Manda los datos de los alumnos al csv. Necesito que aquÃ­ mandes un contador que lleve la cuenta de cuantos alumnos nuevos se pusieron en registro una vez acabado el loop de registro en el main de alumnos.
{
	ofstream myfile("Trial.csv");
	if (myfile.is_open())
	{
		myfile << "Campus,Carrera,ID,Nombre,Edad,Covid,Clase,Semestre,Password,Dia que reservo" << endl;//Manda encabezado de vuelta a csv.
		for (int i = 0; i < personas.size(); i++)
		{
			myfile << personas[i].get_things();//Se mandan los datos de cada estudiante del salon correspondiente de vuelta al csv.
		}
		myfile.close();
	}
	else
		cout << "\nError, ubicacion del archivo no encontrada(alumnos)...";
}
void send_room(salon classroom)//Manda los datos del salon al csv.
{
	ofstream myfile("Clases.csv");
	if (myfile.is_open())
	{
		myfile << "Materia,Capacidad,Espacios disponibles dia 1,Ubicacion,Presencial,Disponibilidad,ID,Espacios disponibles dia 2" << endl;//Manda encabezado a csv.
		myfile << classroom.send_data();//FunciÃ³n que manda al csv los datos del salÃ³n.
	}
	else
		cout << "\nError, ubicacion del archivo(clases) no encontrada...";
}

int receive_room(salon& school)//Recibe los datos del salon del csv.
{
	array<int, 8>comas = { 0 };//Arreglo que guarda la posiciÃ³n de las comas.
	int n = 0;
	int j = 1, cap, available, real, open, id, dis2;//Variables que guardan los valores del csv.
	string registro, place, name;
	ifstream myfile("Clases.csv");
	int fake = 0;
	if (myfile.is_open())
	{
		n = 0;
		cout << "\nSe abrio el archivo" << endl;///para ver si lo abre
		while ((getline(myfile, registro)))
		{
			if (fake == 0) //Se evita guardar el encabezado del csv en las variables.
			{
				fake = 1;
				continue;
			}
			cout << "\nRecuperando datos del salon" << endl;//Guardado de la posiciÃ³n de las comas.
			for (int i = 0; i < registro.size(); i++)
			{
				if (registro.substr(i, 1) == ",")
				{
					comas[j] = i;
					j += 1;
				}
			}
			name = registro.substr(comas[0], comas[1] - comas[0]);//En base a la posiciÃ³n de las comas se guarda cada valor del csv en su respectiva variable.
			cap = stoi(registro.substr(comas[1] + 1, comas[2] - comas[1] - 1));
			available = stoi(registro.substr(comas[2] + 1, comas[3] - comas[2] - 1));
			place = registro.substr(comas[3] + 1, comas[4] - comas[3] - 1);
			real = stoi(registro.substr(comas[4] + 1, comas[5] - comas[4] - 1));
			open = stoi(registro.substr(comas[5] + 1, comas[6] - comas[5] - 1));
			id = stoi(registro.substr(comas[6] + 1, comas[7] - comas[6] - 1));
			dis2 = stoi(registro.substr(comas[7] + 1, registro.size() - comas[7] - 1));
			school.set_all(name, cap, available, place, real, open, id, dis2);//Se mandan las variables al objeto salÃ³n.
			n = 1;
		}
		myfile.close();
	}
	else
		cout << "\nError, ubicacion del archivo(clases) no encontrada...";

	return n;
}