#include <iostream>
#include <string>
#include <vector>
#include "validar.hpp"
#include <fstream>
#include <sstream>
#include <ios>
using namespace std;
int validar(int n1, int n2, string cadena, string opciones);
int main() {
	//Recuperar datos del salon y de los alumnos leer csv
	vector<salon>salones;
	salones.push_back(salon());
	int abierto,r=0;
	abierto = receive_room(salones[0]);
	if (abierto != 0) {
		comprobar(salones[0], salones[0].getCapacidad());
	}
	if (abierto == 0)
		r = 1;
	string n;
	//Cuenta cuantas clases hay registradas para despuies recuperar el dato abajo
	string id;
	//p hace referncia al lugar y m al menu, declaracion de las demas variables a utilizar en el main
	int p_m = 0, s_m = 0, cont = 0, t = 0, reservar = 0, nstudent = 0;
	int b = 0, s3 = 0, dia, s33 = 0;//se usa en la linea 47, en el swith 3
	int diaA = 0, contra = 0;
	int z = 0, modi, admin = 0;
	//Usaremos un vector para ir almacenando a todos los alumnos
	//Primera validacion para saber si se va a registrar o ingresar el alumno o si el administrador va a entrar
	do {
		p_m = validar(0, 3, "a", "\n\t1 - Registro\n\t2 - Ingreso\n\t3 - Administrador\n\t0 - Salir");
		if (p_m == 0) {
			cout << "Hasta luego" << endl;
			break;
		}
		switch (p_m) {
			//En el salon se inqica que se va a registrar un nuevo alumno
		case 1:
			salones[0].nuevoEst();
			break;
		case 2:
			do {
				//Se comprueba que el ID t la contrase�a que se dieron para ingresar coincidan con la info almacenada para verificar la informacion
				cout << "\nIngrese el ID: ";
				cin >> id;
				cout << "\nIngrese la contrasenia: ";
				cin >> contra;
				//permiso es un metodo del estudiante, en este caso se va a ir checando alumno por alumno a ver en cual ed ellos coinciden los datos proporcionados
				for (int i = 0; i < salones[0].getSi(); i++) {
					b = salones[0].getEstudiante(i).permiso(id, contra);//esta funcion regresa 1 si se validan los datos con algun estudiante y 0 si no
					if (b == 1) {
						//si se encuentra que coinciden los datos se guarda la posicion del vector del alumno y para el for
						nstudent = i;
						z = -1;
						break;
					}
				}
				if (b == 0) {
					//si no se encontro coincidencia con los datos registrados anteriormente se notificara que se ingresaron mal los datos 
					cout << "\nUsted ingreso mal los datos o no se ha registrado antes" << endl;
					cout << "Presione culaquier numero para continuar o -1 para salir" << endl;
					cin >> z;
				}
			} while (z != -1);
			//este get Dispo checa si el salon est� abierto o cerrado y notifica de acuerdo al caso a los alumnos si hubo algun caso covid cerca de ellos
			do {
				if (salones[0].getDispo() == 0) {
					cout << "\nEstimado alumno, se le notifica que usted compartio esta clase con un alumno que reporto tener COVID" << endl;
				}
				//menu de alumno
				cout << "\n\t1 - Reservar clases" << endl << "\t2 - Cancelar clases" << endl << "\t3 - Avisar si se enfermo de COVID" << endl << "\t4 - Imprimir mis datos"
					<< endl << "\t5 - Cerrar sesion" << endl;
				s_m = validar(1, 5, "su eleccion porfavor", "1-5");
				if (s_m == 5)
					break;
				switch (s_m) {
				case 1:
					//verifica que el alumno no tenga covid y no tenga registrado otro d�a
					if (salones[0].getEstudiante(nstudent).getCovid() == 0 && salones[0].getEstudiante(nstudent).getDiaA() == 0 && salones[0].getDispo() == 1) {
						dia = validar(1, 2, " alguno de los dias de la materia que quiere asistir: ", "1 - Lunes, 2 - Martes");
						//obtiene primero un alumno del salon despues le asignara el dia que halla escogido de acuerdo a si hay lugares disponibles o no dentro del sal�n
						diaA = salones[0].modificar_lugares_disponibles(dia);
						salones[0].setDIAA(nstudent, diaA);//se le asigna el dia al alumno si es que habia lugar en caso de no haber se le deja un 
						cout << "\nUsted esogio el dia: " << salones[0].getEstudiante(nstudent).getDiaA();
					}
					//Los siguientes else if son razones por las cuales el alumno no puede reservar 
					else if (salones[0].getDispo() == 0)
						cout << "\nLo sentimos este salon esta cerrado porque hubo un caso de COVID" << endl;
					else if (salones[0].getEstudiante(nstudent).getCovid() > 0)
						cout << "\nApreciable alumno, usted no puede registrar clases mientras este enfermo de COVID" << endl;
					else if (salones[0].getEstudiante(nstudent).getDiaA() > 0)
						cout << "\nApreciable alumno, usted no puede reservar mas clases (solo una clase por semana)" << endl;
					break;
				case 2:
					//El alumno no puede cancelar clases una vez que esta funci�n verifica que no ha hecho reservacion alguna
					if (salones[0].getEstudiante(nstudent).getDiaA() == 0)
						cout << "\nApreciable alumno, usted no puede cancelar clases si no ha reservado ninguna" << endl;
					//esta funci�n recibe el dia que el alumno reserv� y lo manda como negativo para que se le cancele el dia e incremente el numero de lugares disponibles en el sal�n
					else {
						diaA = salones[0].modificar_lugares_disponibles(-(salones[0].getEstudiante(nstudent).getDiaA()));
						salones[0].setDIAA(nstudent, diaA);//se manda el numero de posicion dentro del vector del alumno del cual se hacen las modificaciones junto al nuevo dia que reserv�=0
					}

					break;
				case 3:
					salones[0].setCoSal(nstudent);//funcon que llama a un metodo de salon y manda el num que hace referencia al alumno actual y se pregunta sobre su estado en relaci�n a esta enfermedad
					//Dependiendo el estado del alumno derivara en acciones diferentes, en este caso ya no podra reservar clases y si ten�a alguna reservada se le cancelar� automaticamente
					if (salones[0].getEstudiante(nstudent).getCovid() == 1 && salones[0].getEstudiante(nstudent).getDiaA() > 0) {
						cout << "\nUsted reservo una clase la cual sera automaticamente cancelada" << endl;
						diaA = salones[0].modificar_lugares_disponibles(-(salones[0].getEstudiante(nstudent).getDiaA()));
						salones[0].setDIAA(nstudent, diaA);
					}
					//aqu� el alumno dijo que asisitio a clase enfermo por lo que el sal�n se cerrara y nadie m�s podra reservar en este salon
					else if (salones[0].getEstudiante(nstudent).getCovid() == 2)
						cout << "\nMuchas gracias por avisar apreciable alumno, se dara alerta a las demas personas que asistieron a la clase que tiene indicada" << endl;
					break;

				case 4:
					//imprime los datos del alumno
					salones[0].getEstudiante(nstudent).imp_datos();
					break;
				case 5:
					//cierra el menu de alumnos
					cout << "\nHasta luego" << endl;
					break;
				}
			} while (s_m != 5);

			break;
			//Menu del administrador, solo el puede abrir salones
		case 3:
			do {
				//para verificar que la persona que ingresa es un dministrador se pide un codigo
				cout << "\nIngrese el codigo de administrador: ";
				cin >> admin;
				//verificacion del codigo
				if (admin != 6789) {
					cout << "\nNumero incorrecto " << endl;
					break;
				}
				cout << "\nBienvenido administrador" << endl;
				s33 = validar(0, 2, "si desea: ", "1 - Agregar salones, 2 - Ver info de salones y modificarlos, 0 - Salir");
				switch (s33) {
					//en este caso el administrador decidio agregar m�s salones al sistema
				case 1:
					if(r!=1)
					 salones.push_back(salon());
					salones[salones.size() - 1].llenar_datos();
					send_room(salones[salones.size() - 1]);
					r = 0;
					break;
					//esta opci�n le permite conocer algunos datos sobre los salones que se encuentran registrados
				case 2:
					cout << "Salones en base de datos" << endl;
					for (int i = 0; i < salones.size(); i++)
						cout << "Salon " << i + 1 << "\n\tNumero de identificacion del salon: " << salones[i].getID() << "\n\tCapacidad: " << salones[i].getCapacidad()
						<< "\n\tDisponibilidad del salon (1 - Si esta disponible, 0 - No esta disponible): " << salones[i].getDispo() << "\n\tPuede referirse al salon "
						<< i + 1 << " con el indice  " << i << endl;;
					modi = validar(-1, salones.size() - 1, "-1 si no quiere modificar o ingrese le numero de referencia del salon si desea modificar", "alguno de los salones");
					if (modi == -1)
					{
						cout << "\nHasta luego" << endl;
						s33 = 0;
					}
					else {
						//llama a la funcion de imprimir que dependiendo el caso puede abrir o cerrar un sal�n con covid 
						cout << "\nDatos del salon" << endl;
						salones[modi].imprimir();
					}
					break;
				}
			} while (s33 != 0);

			break;
		}
	} while (p_m != 0);
	//llenado de estudiantes al csv
	send_stud(salones[0].getEstudiantes());
	//llenado de salones al csv
	send_room(salones[salones.size() - 1]);
	return 0;
}